<!DOCTYPE html> 

<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="css/animated.css">
    </head>
<body translate="no">

  <div class="heart">
  ❤
  
</div>
<h5 style="text-transform:uppercase">Your booking has been sent, <br> wait for our call in a minute.</h5>
<div class="text">
    
  <p>
    T
  </p>
  <p>
    H
  </p>
  <p>
    A
  </p>
  <p>
    N
  </p>
  <p>
    K
  </p>
  <p>
    &nbsp;
  </p>
  <p>
    Y
  </p>
  <p>
    0
  </p>
  <p>
    U
  </p>
</div>
  
  
  



</body>

<?php 
header("Refresh:5;url=index.php");

?>

</html>
